$(document).ready(function(){
  $('.row').slick({
    'infinite': 'true',
    'slidesToShow': 3,
    'slidesToScroll': 3
  })})

 // $('.slider-views').slick({
   // "arrows": "false",
    //"autoplay": "true",
//});